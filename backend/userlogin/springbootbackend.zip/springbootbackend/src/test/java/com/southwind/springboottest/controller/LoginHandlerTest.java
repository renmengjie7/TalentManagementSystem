package com.southwind.springboottest.controller;

import com.southwind.springboottest.entity.User;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginHandlerTest {


}